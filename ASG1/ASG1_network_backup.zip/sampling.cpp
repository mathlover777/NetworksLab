#ifndef SAMPLING
#define SAMPLING


#endif