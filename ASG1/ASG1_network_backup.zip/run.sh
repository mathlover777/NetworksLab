./driver 50 50 5 125 3 10 1
# gnuplot||plot "original.txt" with lines,"sampled.txt" with lines
