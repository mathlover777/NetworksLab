#include <stdio.h>
#include <stdlib.h>
#include "createsignal.cpp"
#include <math.h>
#include <gsl/gsl_errno.h>
#include <gsl/gsl_spline.h>

const char *ORIGINAL = "original.txt";
const char *SAMPLED = "sampled.txt";
const char *QUANTIZED = "quantized.txt";
const char *TRANSMITED = "transmited.txt";
const char *REQUANTIZED = "requantized.txt";
const char *INTERPOLATED = "interpolated.txt";

void transmit(const char *input,const char *output,double error){
	FILE *fin = fopen(input,"r");
	FILE *fout = fopen(output,"w");
	int sampleCount;
	fscanf(fin,"%d",&sampleCount);
	fprintf(fout,"%d\n",sampleCount);
	double t,amp;
	for(int i=0;i<sampleCount;i++){
		fscanf(fin,"%lf %lf",&t,&amp);
		if(rand()%2==1){
			// positive
			amp = amp + fRand(0,error);
		}else{
			// negative
			amp = amp - fRand(0,error);
		}
		fprintf(fout, "%lf %lf\n",t,amp);
	}
	fclose(fin);
	fclose(fout);
	return;
}
void quantize(const char* sampled,const char *quantized,int l,double width){
	FILE *fIn = fopen(sampled,"r");
	FILE  *fOut = fopen(quantized,"w");
	int i, count;
	double time1,value1,value2,temp;
	fscanf(fIn,"%d",&count);
	fprintf(fOut,"%d\n",count);
	for(i = 0; i < count; i++){
		fscanf(fIn,"%lf%lf",&time1,&value1);
		if(value1 > (width * l)){
			value2 = width * l;
			fprintf(fOut,"%lf %lf\n",time1,value2);
			continue;
		}
		if(value1 < (-width * l)){
			value2 = -width * l;
			fprintf(fOut,"%lf %lf\n",time1,value2);
			continue;	
		}
		temp = value1 / width;
		if(temp >= 0){
			value2 = ((int)(temp + 0.5)) * width;
		}
		else{
			value2 = ((int)(temp - 0.5)) * width;
		}
		fprintf(fOut,"%lf %lf\n",time1,value2);
	}
	fclose(fIn);
	fclose(fOut);
	return;
}
void interpolate(const char *inputfile,const char *interpolated,double freq){
	FILE *f,*g;
	f = fopen(inputfile,"r");
	int sampleCount;
	fscanf(f,"%d",&sampleCount);
	double t[sampleCount],amp[sampleCount];
	for(int i=0;i<sampleCount;i++){
		fscanf(f,"%lf %lf",t+i,amp+i);
	}
	fclose(f);

	gsl_interp_accel *acc = gsl_interp_accel_alloc ();
    gsl_spline *spline = gsl_spline_alloc (gsl_interp_cspline, sampleCount);
    gsl_spline_init(spline, t, amp, sampleCount);

    f = fopen("temp.txt","w");
    double tDiff = 1.0/freq;
    double t_i,amp_i;
    int sCount = 0;
    // printf("\nT = %lf",t[sampleCount-1]);
    for(t_i = t[0];t_i<t[sampleCount-1];t_i = t_i + tDiff){
    	amp_i = gsl_spline_eval(spline,t_i,acc);
    	fprintf(f, "%lf %lf\n",t_i,amp_i);
    	sCount++;
    }
    fclose(f);

    f = fopen(interpolated,"w");
    g = fopen("temp.txt","r");
    
    fprintf(f, "%d\n",sCount);
    for(int i=0;i<sCount;i++){
    	fscanf(g,"%lf %lf",&t_i,&amp_i);
    	fprintf(f, "%lf %lf\n",t_i,amp_i);
    }
    fclose(f);
    fclose(g);
    return;
}
double calc_mean_square_error(const char* f1,const char* f2){
    FILE *orig,*new_;
    int count,n;
    double time1,time2,value1,value2,error;
    orig = fopen(f1,"r");
    new_ = fopen(f2,"r");
    fscanf(orig,"%d",&count);
    fscanf(new_,"%d",&n);
    if(count < n){
        n = count;
    }
    else{
        count = n;
    }
    //printf("%d %d\n",count,n);
    while(count--){
        fscanf(orig,"%lf%lf",&time1,&value1);
        fscanf(new_,"%lf%lf",&time2,&value2);
        //printf("%lf %lf\n",value1,value2);
        error += (value1-value2)*(value1-value2);
    }
    fclose(orig);
    fclose(new_);
    error /= n;
    return error;
}
// int main(){
// 	interpolate("requantized.txt","interpolated.txt",5000);
//     double error = calc_mean_square_error("original.txt","interpolated.txt");
// 	printf("\nERROR = %lf",error);
//     printf("\n");
//     return 0;
// }

int main(int argc,char **argv){
	double fMax,A,fSample,qDist,eMax,len;
	int nComp;
	double freq[100],amp[100];
	sscanf(argv[1],"%lf",&fMax);
	sscanf(argv[2],"%lf",&A);
	sscanf(argv[3],"%d",&nComp);
	// sscanf(argv[4],"%lf",&fSample);
	// sscanf(argv[5],"%lf",&qDist);
	sscanf(argv[4],"%lf",&eMax);
	sscanf(argv[5],"%lf",&len);
	// /**********************************************/

	// ******** signal parameters *****************
	generateFreq_Amp(nComp,freq,amp,fMax,A);
	// /**********************************************/

	// /********* generate original signal ***********/
	createOriginalSignal(nComp,freq,amp,fMax,ORIGINAL,len);
	// /**********************************************/
	int l = (A * nComp /eMax);
	
	printf("\noriginal created\n");

	FILE *f = fopen("errordata.txt","w");
	double error;
	printf("\nFMAX * 4 = %lf",fMax *4);
	for(fSample = 4;fSample<fMax * 4;fSample = fSample+.5){
		printf("\nFSAMPLE = %lf",fSample);
		sample(nComp,freq,amp,fSample,SAMPLED,len);
		// printf("\nL = %d\teMax = %lf\n",l,eMax);
		quantize(SAMPLED,QUANTIZED,l,eMax);
		transmit(QUANTIZED,TRANSMITED,eMax/2);
		quantize(TRANSMITED,REQUANTIZED,l,eMax);
		interpolate(REQUANTIZED,INTERPOLATED,5000);
		error = calc_mean_square_error("original.txt","interpolated.txt");
		fprintf(f,"%lf %lf\n",fSample,error);
	}
	fclose(f);
	printf("\n");
	return 0;
}