export DISPLAY=:0.0
xdotool windowactivate 0x03e00015
xdotool windowfocus 0x03e00015
xdotool windowsize 0x03e00015 600 500
