export DISPLAY=:0.0
xdotool windowactivate 0x05600015
xdotool windowfocus 0x05600015
xdotool key "ctrl+g"
sleep 1
xdotool key KP_Delete
xdotool key 2
xdotool key 0
xdotool key KP_Enter
