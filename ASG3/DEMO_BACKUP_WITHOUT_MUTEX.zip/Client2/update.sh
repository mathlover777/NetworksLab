export DISPLAY=:0.0
xdotool windowactivate 0x05a00015
xdotool windowfocus 0x05a00015
